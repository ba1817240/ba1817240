/*
 * File:   main.cpp
 * Author: Brandon Arias
 * Created on January 10, 2016, 4:25 PM
 * Purpose: Make a Triangle
 */

//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function prototypes

//Execution Begins Here
int main(int argc, char** argv)

{
    //Display triangle
    cout << "    *     " << endl;
    cout << "   ***    " << endl;
    cout << "  *****   " << endl;
    cout << " *******  " << endl;

    //End program
    return 0;
}