/*
 * File:   main.cpp
 * Author: Brandon Arias
 * Created on January 10, 2016, 11:54 PM
 * Purpose: Personal Information
 */

//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants
const string NAME = "Your Name:";
const string ADD = "Your Address, with city, state and ZIP code:";
const string PH = "Your Telephone Number:";
const string MAJOR = "Your college major:";
//Function prototypes

//Execution Begins Here
int main(int argc, char** argv)

{
    //Display Information
    cout << NAME << endl
         << ADD << endl
         << PH << endl
         << MAJOR << endl;
    //***Sorry I have an issue with putting out my personal info***
    
    //End program
    return 0;
}
